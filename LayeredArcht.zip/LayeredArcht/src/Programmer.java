
public final class Programmer extends Employee{
	Programmer(String name,int age){
	    super(name,age,"Programmer",15000);
	    
	}
	Programmer(){
		
	}

}
