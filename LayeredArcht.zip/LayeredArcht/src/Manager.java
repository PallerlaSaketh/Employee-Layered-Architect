
public final class Manager extends Employee{
	Manager(String name,int age){
	    super(name,age,"Manager",15000);
	    
	}
	Manager(){
		
	}

}