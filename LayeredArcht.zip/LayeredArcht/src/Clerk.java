
public final class Clerk extends Employee{
	Clerk(String name,int age){
	    super(name,age,"Clerk",15000);
	    
	}
	Clerk(){
		
	}

}
